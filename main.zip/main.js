 // Function to handle button click event
        function redirectToMainPage() {
            // Redirect to main page
            window.location.href = 'qlsv.html';
        }

        // Add event listener to the button
        document.getElementById('loginButton').addEventListener('click', redirectToMainPage);
